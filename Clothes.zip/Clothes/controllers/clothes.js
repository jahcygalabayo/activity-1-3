/*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
import { Clothes, sequelize } from "../models/Clothes.js";

await sequelize.sync();

const clothes = {
  index: async (req, res) => {
    const data = await Clothes.findAll();
    res.render("clothes", { data });
  },

  insert: async (req, res) => {
    const { Name, Category, Size, Color, Price, Quantity } = req.body;
    const data = await Clothes.create({ Name, Category, Size, Color, Price, Quantity  });

    const isJson = req.headers["content-type"]?.includes("application/json");
    if (isJson) {
      return res.json(data);
    }
    res.redirect("/clothes");
  },

  get: async (req, res) => {
    const data = await Clothes.findAll();
    res.json(data);
  },

  show: async (req, res) => {
    const { id } = req.params;
    const data = await Clothes.findByPk(id);
    res.json(data);
  },

  update: async (req, res) => {
    const { id } = req.params;
    const { Name, Category, Size, Color, Price, Quantity  } = req.body;

    await Clothes.update(
      { Name, Category, Size, Color, Price, Quantity },
      { where: { id } }
    );

    const updatedData = await Clothes.findByPk(id);
    const isJson = req.headers["content-type"]?.includes("application/json");
    if (isJson) {
      return res.json(updatedData);
    }
    res.redirect("/clothes");
  },

  delete: async (req, res) => {
    const { id } = req.params;
    await Clothes.destroy({ where: { id } });

    const isJson = req.headers["content-type"]?.includes("application/json");
    if (isJson) {
      return res.json({ message: "Deleted successfully" });
    }
    res.redirect("/clothes");
  },
  // Idagdag ito sa loob ng clothes object sa controllers/clothes.js
  editForm: async (req, res) => {
    const { id } = req.params;
    const clothes = await Clothes.findByPk(id);
    res.render("edit", { clothes });
  },
};

export { clothes };